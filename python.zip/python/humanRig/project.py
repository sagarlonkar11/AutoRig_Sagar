"""

main project file with central variables
"""

scene_scale = 1.0
project_path = 'D:/AutoRig_sagar/assets/'


"""

https://www.youtube.com/watch?v=sHLz5LzSns8

import humanRig
import rigLib
import maya.cmds as cmds

reload(humanRig.human)
reload(humanRig.human_deform)

reload(rigLib.base.module)
reload(rigLib.base.control)

reload(rigLib.utils.joint)

reload(rigLib.rig.spine)
reload(rigLib.rig.neck)
reload(rigLib.rig.ikChain)
reload(rigLib.rig.leg)
reload(rigLib.rig.hand)
reload(rigLib.rig.head_parts)

# Build 
character_name = 'human'
humanRig.human.build(character_name)
"""